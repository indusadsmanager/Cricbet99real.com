// Casino Demo - Main JavaScript

// Global State
let userBalance = 10000;
let selectedPaymentMethod = null;
let selectedWithdrawMethod = null;
let deposits = [];
let withdrawals = [];
let transactions = [];
let currentBlackjackHand = [];
let dealerHand = [];
let blackjackBet = 0;
let gameInProgress = false;

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadUserData();
    updateBalanceDisplay();
    updateTransactionTables();
});

// User Data Management
function loadUserData() {
    const savedBalance = localStorage.getItem('userBalance');
    const savedDeposits = localStorage.getItem('deposits');
    const savedWithdrawals = localStorage.getItem('withdrawals');
    
    if (savedBalance) {
        userBalance = parseFloat(savedBalance);
    }
    if (savedDeposits) {
        deposits = JSON.parse(savedDeposits);
    }
    if (savedWithdrawals) {
        withdrawals = JSON.parse(savedWithdrawals);
    }
}

function saveUserData() {
    localStorage.setItem('userBalance', userBalance);
    localStorage.setItem('deposits', JSON.stringify(deposits));
    localStorage.setItem('withdrawals', JSON.stringify(withdrawals));
}

// Navigation
function showPage(pageName) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.style.display = 'none';
    });
    
    // Show selected page
    const targetPage = document.getElementById(pageName + 'Page');
    if (targetPage) {
        targetPage.style.display = 'block';
    }
}

function showGame(gameName) {
    showPage(gameName + 'Game');
}

// Balance Management
function updateBalanceDisplay() {
    const balanceElements = document.querySelectorAll('#userBalance, #walletBalance');
    balanceElements.forEach(element => {
        element.textContent = '$' + userBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    });
}

// Notification System
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// ==================== SLOT MACHINE GAME ====================
const slotSymbols = ['🍒', '🍋', '🍊', '💎', '7️⃣'];
const slotPayouts = {
    '🍒': 5,
    '🍋': 10,
    '🍊': 15,
    '💎': 25,
    '7️⃣': 100
};

function placeSlotBet() {
    const betAmount = parseInt(document.getElementById('slotBetAmount').value);
    
    if (betAmount > userBalance) {
        showNotification('Insufficient balance!', 'error');
        return;
    }
    
    if (betAmount < 1 || betAmount > 1000) {
        showNotification('Bet must be between $1 and $1000', 'error');
        return;
    }
    
    // Deduct bet
    userBalance -= betAmount;
    updateBalanceDisplay();
    
    document.getElementById('currentSlotBet').textContent = '$' + betAmount;
    
    // Spin reels
    const reels = [
        document.getElementById('reel1'),
        document.getElementById('reel2'),
        document.getElementById('reel3')
    ];
    
    // Add spinning animation
    reels.forEach(reel => reel.classList.add('spinning'));
    
    // Spin animation duration
    setTimeout(() => {
        // Stop reels one by one
        const results = [];
        reels.forEach((reel, index) => {
            setTimeout(() => {
                reel.classList.remove('spinning');
                const symbol = slotSymbols[Math.floor(Math.random() * slotSymbols.length)];
                reel.textContent = symbol;
                results[index] = symbol;
                
                // Check result after all reels stop
                if (index === 2) {
                    checkSlotResult(results, betAmount);
                }
            }, (index + 1) * 500);
        });
    }, 500);
}

function checkSlotResult(results, betAmount) {
    const resultDiv = document.getElementById('slotResult');
    
    if (results[0] === results[1] && results[1] === results[2]) {
        // Win!
        const symbol = results[0];
        const multiplier = slotPayouts[symbol];
        const winnings = betAmount * multiplier;
        
        userBalance += winnings;
        updateBalanceDisplay();
        saveUserData();
        
        resultDiv.textContent = `🎉 WIN! ${symbol}${symbol}${symbol} - You won $${winnings}!`;
        resultDiv.style.color = '#00ff88';
        showNotification(`Congratulations! You won $${winnings}!`, 'success');
        
        // Add transaction
        addTransaction('win', winnings, `Slots win - ${symbol}${symbol}${symbol}`);
    } else {
        // Loss
        resultDiv.textContent = 'Try again!';
        resultDiv.style.color = '#ff4757';
        
        addTransaction('bet', betAmount, 'Slots bet');
        saveUserData();
    }
}

function maxBetSlot() {
    document.getElementById('slotBetAmount').value = 1000;
}

// ==================== ROULETTE GAME ====================
function placeRouletteBet(betType) {
    const betAmount = parseInt(document.getElementById('rouletteBetAmount').value);
    
    if (betAmount > userBalance) {
        showNotification('Insufficient balance!', 'error');
        return;
    }
    
    if (betAmount < 1 || betAmount > 1000) {
        showNotification('Bet must be between $1 and $1000', 'error');
        return;
    }
    
    // Deduct bet
    userBalance -= betAmount;
    updateBalanceDisplay();
    
    document.getElementById('currentRouletteBet').textContent = '$' + betAmount;
    
    // Spin wheel
    const wheel = document.getElementById('rouletteWheel');
    const randomDegree = Math.floor(Math.random() * 360) + 720; // At least 2 full spins
    wheel.style.transform = `rotate(${randomDegree}deg)`;
    
    setTimeout(() => {
        // Determine result
        const degree = randomDegree % 360;
        let result;
        
        if (degree >= 355 || degree < 5) {
            result = 'green';
        } else if (degree % 2 === 0) {
            result = 'red';
        } else {
            result = 'black';
        }
        
        checkRouletteResult(result, betType, betAmount);
    }, 4000);
}

function checkRouletteResult(result, betType, betAmount) {
    const resultDiv = document.getElementById('rouletteResult');
    
    if (result === betType) {
        let winnings;
        if (result === 'green') {
            winnings = betAmount * 35; // 35:1 payout for green
        } else {
            winnings = betAmount * 2; // 1:1 payout for red/black
        }
        
        userBalance += winnings;
        updateBalanceDisplay();
        saveUserData();
        
        resultDiv.textContent = `🎉 ${result.toUpperCase()}! You won $${winnings}!`;
        resultDiv.style.color = '#00ff88';
        showNotification(`Congratulations! You won $${winnings}!`, 'success');
        
        addTransaction('win', winnings, `Roulette win - ${result}`);
    } else {
        resultDiv.textContent = `${result.toUpperCase()}! Better luck next time!`;
        resultDiv.style.color = '#ff4757';
        
        addTransaction('bet', betAmount, `Roulette bet - ${betType}`);
        saveUserData();
    }
}

// ==================== BLACKJACK GAME ====================
const suits = ['♥', '♦', '♣', '♠'];
const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

function createDeck() {
    let deck = [];
    for (let suit of suits) {
        for (let value of values) {
            deck.push({ suit, value });
        }
    }
    return deck;
}

function shuffleDeck(deck) {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function getCardValue(card) {
    if (['J', 'Q', 'K'].includes(card.value)) {
        return 10;
    } else if (card.value === 'A') {
        return 11;
    } else {
        return parseInt(card.value);
    }
}

function calculateHandValue(hand) {
    let value = 0;
    let aces = 0;
    
    for (let card of hand) {
        value += getCardValue(card);
        if (card.value === 'A') {
            aces++;
        }
    }
    
    while (value > 21 && aces > 0) {
        value -= 10;
        aces--;
    }
    
    return value;
}

function renderCard(card, container) {
    const cardElement = document.createElement('div');
    cardElement.className = `card ${['♥', '♦'].includes(card.suit) ? 'red' : 'black'}`;
    cardElement.innerHTML = `
        <div>${card.value}</div>
        <div>${card.suit}</div>
    `;
    container.appendChild(cardElement);
}

function renderHand(hand, containerId) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    hand.forEach(card => renderCard(card, container));
}

function deal() {
    const betAmount = parseInt(document.getElementById('blackjackBetAmount').value);
    
    if (betAmount > userBalance) {
        showNotification('Insufficient balance!', 'error');
        return;
    }
    
    if (gameInProgress) {
        showNotification('Game already in progress!', 'error');
        return;
    }
    
    blackjackBet = betAmount;
    userBalance -= betAmount;
    updateBalanceDisplay();
    
    const deck = shuffleDeck(createDeck());
    currentBlackjackHand = [deck.pop(), deck.pop()];
    dealerHand = [deck.pop(), deck.pop()];
    
    gameInProgress = true;
    
    renderHand(currentBlackjackHand, 'playerHand');
    renderHand(dealerHand, 'dealerHand');
    
    document.getElementById('playerScore').textContent = calculateHandValue(currentBlackjackHand);
    document.getElementById('dealerScore').textContent = getCardValue(dealerHand[0]); // Show only first card value
    
    document.getElementById('hitBtn').disabled = false;
    document.getElementById('standBtn').disabled = false;
    document.getElementById('dealBtn').disabled = true;
    
    document.getElementById('blackjackResult').textContent = '';
    
    addTransaction('bet', betAmount, 'Blackjack bet');
}

function hit() {
    const deck = shuffleDeck(createDeck());
    currentBlackjackHand.push(deck.pop());
    
    renderHand(currentBlackjackHand, 'playerHand');
    document.getElementById('playerScore').textContent = calculateHandValue(currentBlackjackHand);
    
    if (calculateHandValue(currentBlackjackHand) > 21) {
        endBlackjackGame('bust');
    }
}

function stand() {
    // Dealer's turn
    while (calculateHandValue(dealerHand) < 17) {
        const deck = shuffleDeck(createDeck());
        dealerHand.push(deck.pop());
    }
    
    renderHand(dealerHand, 'dealerHand');
    document.getElementById('dealerScore').textContent = calculateHandValue(dealerHand);
    
    const playerValue = calculateHandValue(currentBlackjackHand);
    const dealerValue = calculateHandValue(dealerHand);
    
    if (dealerValue > 21) {
        endBlackjackGame('dealer_bust');
    } else if (playerValue > dealerValue) {
        endBlackjackGame('win');
    } else if (playerValue < dealerValue) {
        endBlackjackGame('lose');
    } else {
        endBlackjackGame('push');
    }
}

function endBlackjackGame(result) {
    const resultDiv = document.getElementById('blackjackResult');
    gameInProgress = false;
    
    document.getElementById('hitBtn').disabled = true;
    document.getElementById('standBtn').disabled = true;
    document.getElementById('dealBtn').disabled = false;
    
    switch (result) {
        case 'bust':
            resultDiv.textContent = '💥 Bust! You went over 21!';
            resultDiv.style.color = '#ff4757';
            saveUserData();
            break;
        case 'dealer_bust':
            const bustWinnings = blackjackBet * 2;
            userBalance += bustWinnings;
            updateBalanceDisplay();
            resultDiv.textContent = `🎉 Dealer busts! You win $${bustWinnings}!`;
            resultDiv.style.color = '#00ff88';
            showNotification(`You won $${bustWinnings}!`, 'success');
            addTransaction('win', bustWinnings, 'Blackjack win - dealer bust');
            saveUserData();
            break;
        case 'win':
            const winWinnings = blackjackBet * 2;
            userBalance += winWinnings;
            updateBalanceDisplay();
            resultDiv.textContent = `🎉 You win $${winWinnings}!`;
            resultDiv.style.color = '#00ff88';
            showNotification(`You won $${winWinnings}!`, 'success');
            addTransaction('win', winWinnings, 'Blackjack win');
            saveUserData();
            break;
        case 'lose':
            resultDiv.textContent = '😢 Dealer wins!';
            resultDiv.style.color = '#ff4757';
            saveUserData();
            break;
        case 'push':
            userBalance += blackjackBet; // Return bet
            updateBalanceDisplay();
            resultDiv.textContent = '🤝 Push! Bet returned.';
            resultDiv.style.color = '#ffd700';
            saveUserData();
            break;
    }
}

// ==================== POKER GAME ====================
function playPoker() {
    const betAmount = parseInt(document.getElementById('pokerBetAmount').value);
    
    if (betAmount > userBalance) {
        showNotification('Insufficient balance!', 'error');
        return;
    }
    
    userBalance -= betAmount;
    updateBalanceDisplay();
    
    document.getElementById('currentPokerBet').textContent = '$' + betAmount;
    
    const deck = shuffleDeck(createDeck());
    
    // Deal player hand
    const playerHand = [deck.pop(), deck.pop()];
    
    // Deal community cards
    const communityCards = [deck.pop(), deck.pop(), deck.pop(), deck.pop(), deck.pop()];
    
    // Render cards
    const playerContainer = document.getElementById('playerPokerHand');
    playerContainer.innerHTML = '';
    playerHand.forEach(card => renderCard(card, playerContainer));
    
    const communityContainer = document.getElementById('communityCards');
    communityContainer.innerHTML = '';
    communityCards.forEach(card => renderCard(card, communityContainer));
    
    // Determine winner (simplified)
    setTimeout(() => {
        const playerWins = Math.random() > 0.5;
        const resultDiv = document.getElementById('pokerResult');
        
        if (playerWins) {
            const winnings = betAmount * 2;
            userBalance += winnings;
            updateBalanceDisplay();
            saveUserData();
            
            resultDiv.textContent = `🎉 You win $${winnings}!`;
            resultDiv.style.color = '#00ff88';
            showNotification(`You won $${winnings}!`, 'success');
            addTransaction('win', winnings, 'Poker win');
        } else {
            resultDiv.textContent = '😢 You lose this hand!';
            resultDiv.style.color = '#ff4757';
            addTransaction('bet', betAmount, 'Poker bet');
            saveUserData();
        }
    }, 1000);
}

// ==================== PAYMENT METHODS ====================
function showDepositModal() {
    document.getElementById('depositModal').classList.add('active');
}

function closeDepositModal() {
    document.getElementById('depositModal').classList.remove('active');
    selectedPaymentMethod = null;
    document.getElementById('paymentDetails').style.display = 'none';
}

function showWithdrawModal() {
    document.getElementById('withdrawModal').classList.add('active');
}

function closeWithdrawModal() {
    document.getElementById('withdrawModal').classList.remove('active');
    selectedWithdrawMethod = null;
}

function selectPaymentMethod(element, method) {
    document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    selectedPaymentMethod = method;
    
    if (method === 'creditcard') {
        document.getElementById('paymentDetails').style.display = 'block';
    } else {
        document.getElementById('paymentDetails').style.display = 'none';
    }
}

function selectWithdrawMethod(element, method) {
    document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    selectedWithdrawMethod = method;
}

function processDeposit() {
    const amount = parseFloat(document.getElementById('depositAmount').value);
    
    if (!selectedPaymentMethod) {
        showNotification('Please select a payment method', 'error');
        return;
    }
    
    if (amount < 10 || amount > 10000) {
        showNotification('Deposit amount must be between $10 and $10,000', 'error');
        return;
    }
    
    // Simulate deposit processing
    showNotification('Processing deposit...', 'info');
    
    setTimeout(() => {
        const deposit = {
            id: Date.now(),
            date: new Date().toLocaleString(),
            method: selectedPaymentMethod,
            amount: amount,
            status: 'completed'
        };
        
        deposits.push(deposit);
        userBalance += amount;
        updateBalanceDisplay();
        saveUserData();
        updateTransactionTables();
        
        closeDepositModal();
        showNotification(`Deposit of $${amount} successful!`, 'success');
        addTransaction('deposit', amount, `Deposit via ${selectedPaymentMethod}`);
    }, 2000);
}

function processWithdraw() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    const address = document.getElementById('withdrawAddress').value;
    
    if (!selectedWithdrawMethod) {
        showNotification('Please select a withdrawal method', 'error');
        return;
    }
    
    if (!address) {
        showNotification('Please enter withdrawal address', 'error');
        return;
    }
    
    if (amount < 10 || amount > userBalance) {
        showNotification('Invalid withdrawal amount', 'error');
        return;
    }
    
    // Simulate withdrawal processing
    showNotification('Processing withdrawal...', 'info');
    
    setTimeout(() => {
        const withdrawal = {
            id: Date.now(),
            date: new Date().toLocaleString(),
            method: selectedWithdrawMethod,
            amount: amount,
            address: address,
            status: 'completed'
        };
        
        withdrawals.push(withdrawal);
        userBalance -= amount;
        updateBalanceDisplay();
        saveUserData();
        updateTransactionTables();
        
        closeWithdrawModal();
        showNotification(`Withdrawal of $${amount} successful!`, 'success');
        addTransaction('withdrawal', amount, `Withdrawal via ${selectedWithdrawMethod}`);
    }, 2000);
}

// ==================== TRANSACTIONS ====================
function addTransaction(type, amount, description) {
    const transaction = {
        id: Date.now(),
        date: new Date().toLocaleString(),
        type: type,
        amount: amount,
        description: description
    };
    
    transactions.unshift(transaction);
}

function updateTransactionTables() {
    // Update deposits table
    const depositsTable = document.getElementById('depositsTable');
    if (deposits.length === 0) {
        depositsTable.innerHTML = '<tr><td colspan="4" style="text-align: center;">No deposits yet</td></tr>';
    } else {
        depositsTable.innerHTML = deposits.map(dep => `
            <tr>
                <td>${dep.date}</td>
                <td>${dep.method}</td>
                <td>$${dep.amount.toFixed(2)}</td>
                <td><span class="status ${dep.status}">${dep.status}</span></td>
            </tr>
        `).join('');
    }
    
    // Update withdrawals table
    const withdrawalsTable = document.getElementById('withdrawalsTable');
    if (withdrawals.length === 0) {
        withdrawalsTable.innerHTML = '<tr><td colspan="4" style="text-align: center;">No withdrawals yet</td></tr>';
    } else {
        withdrawalsTable.innerHTML = withdrawals.map(withd => `
            <tr>
                <td>${withd.date}</td>
                <td>${withd.method}</td>
                <td>$${withd.amount.toFixed(2)}</td>
                <td><span class="status ${withd.status}">${withd.status}</span></td>
            </tr>
        `).join('');
    }
    
    // Update transactions table
    const transactionsTable = document.getElementById('transactionsTable');
    if (transactions.length === 0) {
        transactionsTable.innerHTML = '<tr><td colspan="4" style="text-align: center;">No transactions yet</td></tr>';
    } else {
        transactionsTable.innerHTML = transactions.slice(0, 20).map(trans => `
            <tr>
                <td>${trans.date}</td>
                <td>${trans.type}</td>
                <td>$${trans.amount.toFixed(2)}</td>
                <td>${trans.description}</td>
            </tr>
        `).join('');
    }
}

function showWalletTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName + 'Tab').classList.add('active');
    
    // Add active class to clicked tab button
    event.target.classList.add('active');
}

// ==================== PROFILE ====================
function updateProfile() {
    const username = document.getElementById('profileUsername').value;
    const email = document.getElementById('profileEmail').value;
    
    localStorage.setItem('username', username);
    localStorage.setItem('email', email);
    
    showNotification('Profile updated successfully!', 'success');
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.clear();
        location.reload();
    }
}

// ==================== ADMIN DASHBOARD ====================
function showAdminLogin() {
    document.getElementById('adminLoginModal').classList.add('active');
}

function closeAdminLogin() {
    document.getElementById('adminLoginModal').classList.remove('active');
}

function adminLogin() {
    const username = document.getElementById('adminUsername').value;
    const password = document.getElementById('adminPassword').value;
    
    if (username === 'admin' && password === 'admin123') {
        closeAdminLogin();
        showAdminDashboard();
    } else {
        showNotification('Invalid credentials!', 'error');
    }
}

function showAdminDashboard() {
    // Create admin dashboard
    const adminHTML = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Admin Dashboard - CasinoBet99</title>
            <link rel="stylesheet" href="styles.css">
        </head>
        <body>
            <div class="admin-layout">
                <div class="admin-sidebar">
                    <h2 style="color: var(--gold); margin-bottom: 2rem;">🔐 Admin Panel</h2>
                    <ul class="admin-menu">
                        <li><a href="#" class="active" onclick="showAdminSection('dashboard')">📊 Dashboard</a></li>
                        <li><a href="#" onclick="showAdminSection('payments')">💳 Payment Methods</a></li>
                        <li><a href="#" onclick="showAdminSection('deposits')">💰 Deposits</a></li>
                        <li><a href="#" onclick="showAdminSection('withdrawals')">💸 Withdrawals</a></li>
                        <li><a href="#" onclick="showAdminSection('users')">👥 Users</a></li>
                        <li><a href="#" onclick="showAdminSection('settings')">⚙️ Settings</a></li>
                        <li><a href="#" onclick="exitAdmin()">🚪 Exit Admin</a></li>
                    </ul>
                </div>
                
                <div class="admin-content">
                    <div id="adminDashboard">
                        <h1>📊 Dashboard Overview</h1>
                        
                        <div class="dashboard-stats">
                            <div class="stat-card">
                                <h3>Total Users</h3>
                                <div class="value">1,234</div>
                            </div>
                            <div class="stat-card">
                                <h3>Total Deposits</h3>
                                <div class="value">$45,678.00</div>
                            </div>
                            <div class="stat-card">
                                <h3>Total Withdrawals</h3>
                                <div class="value">$12,345.00</div>
                            </div>
                            <div class="stat-card">
                                <h3>Active Games</h3>
                                <div class="value">89</div>
                            </div>
                            <div class="stat-card">
                                <h3>Total Revenue</h3>
                                <div class="value">$33,333.00</div>
                            </div>
                            <div class="stat-card">
                                <h3>Pending Requests</h3>
                                <div class="value">5</div>
                            </div>
                        </div>
                        
                        <h2 style="margin-bottom: 1rem;">Recent Activity</h2>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>2024-01-15 14:30</td>
                                    <td>user123</td>
                                    <td>Deposit</td>
                                    <td>$500.00</td>
                                    <td><span class="status completed">Completed</span></td>
                                </tr>
                                <tr>
                                    <td>2024-01-15 14:25</td>
                                    <td>user456</td>
                                    <td>Withdrawal</td>
                                    <td>$200.00</td>
                                    <td><span class="status pending">Pending</span></td>
                                </tr>
                                <tr>
                                    <td>2024-01-15 14:20</td>
                                    <td>user789</td>
                                    <td>Game Bet</td>
                                    <td>$50.00</td>
                                    <td><span class="status completed">Completed</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div id="adminPayments" style="display: none;">
                        <h1>💳 Payment Methods Management</h1>
                        
                        <div style="margin-bottom: 2rem;">
                            <h3>Add New Payment Method</h3>
                            <div class="form-group">
                                <label>Method Name</label>
                                <input type="text" class="form-control" id="newPaymentMethod" placeholder="e.g., PayPal">
                            </div>
                            <div class="form-group">
                                <label>Processing Fee (%)</label>
                                <input type="number" class="form-control" id="paymentFee" value="0">
                            </div>
                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control">
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                            <button class="btn btn-primary" onclick="addPaymentMethod()">Add Payment Method</button>
                        </div>
                        
                        <h3>Active Payment Methods</h3>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Method</th>
                                    <th>Fee</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>💳 Credit Card</td>
                                    <td>2.5%</td>
                                    <td><span class="status completed">Active</span></td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">Edit</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Disable</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>₿ Bitcoin</td>
                                    <td>1.0%</td>
                                    <td><span class="status completed">Active</span></td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">Edit</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Disable</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Ξ Ethereum</td>
                                    <td>1.5%</td>
                                    <td><span class="status completed">Active</span></td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">Edit</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Disable</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>🏦 Bank Transfer</td>
                                    <td>0%</td>
                                    <td><span class="status completed">Active</span></td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">Edit</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Disable</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div id="adminDeposits" style="display: none;">
                        <h1>💰 Deposit Management</h1>
                        
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Date</th>
                                    <th>Method</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>#1001</td>
                                    <td>user123</td>
                                    <td>2024-01-15 14:30</td>
                                    <td>Bitcoin</td>
                                    <td>$500.00</td>
                                    <td><span class="status completed">Completed</span></td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">View</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#1002</td>
                                    <td>user456</td>
                                    <td>2024-01-15 14:25</td>
                                    <td>Credit Card</td>
                                    <td>$1,000.00</td>
                                    <td><span class="status pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-success" style="padding: 0.3rem 0.6rem;">Approve</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Reject</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div id="adminWithdrawals" style="display: none;">
                        <h1>💸 Withdrawal Management</h1>
                        
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Date</th>
                                    <th>Method</th>
                                    <th>Amount</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>#2001</td>
                                    <td>user789</td>
                                    <td>2024-01-15 14:20</td>
                                    <td>Bitcoin</td>
                                    <td>$200.00</td>
                                    <td>bc1q...</td>
                                    <td><span class="status pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-success" style="padding: 0.3rem 0.6rem;">Approve</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Reject</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#2002</td>
                                    <td>user321</td>
                                    <td>2024-01-15 14:15</td>
                                    <td>Bank Transfer</td>
                                    <td>$500.00</td>
                                    <td>****1234</td>
                                    <td><span class="status completed">Completed</span></td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">View</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div id="adminUsers" style="display: none;">
                        <h1>👥 User Management</h1>
                        
                        <div style="margin-bottom: 2rem;">
                            <input type="text" class="form-control" placeholder="Search users..." style="max-width: 300px;">
                        </div>
                        
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Balance</th>
                                    <th>Status</th>
                                    <th>Joined</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>#1</td>
                                    <td>DemoUser</td>
                                    <td>demo@casino.com</td>
                                    <td>$10,000.00</td>
                                    <td><span class="status completed">Active</span></td>
                                    <td>2024-01-01</td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">Edit</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Ban</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#2</td>
                                    <td>player123</td>
                                    <td>player@email.com</td>
                                    <td>$5,234.00</td>
                                    <td><span class="status completed">Active</span></td>
                                    <td>2024-01-10</td>
                                    <td>
                                        <button class="btn btn-primary" style="padding: 0.3rem 0.6rem;">Edit</button>
                                        <button class="btn btn-danger" style="padding: 0.3rem 0.6rem;">Ban</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div id="adminSettings" style="display: none;">
                        <h1>⚙️ Settings</h1>
                        
                        <div style="background: var(--card-bg); padding: 2rem; border-radius: 10px;">
                            <div class="form-group">
                                <label>Casino Name</label>
                                <input type="text" class="form-control" value="CasinoBet99">
                            </div>
                            <div class="form-group">
                                <label>Minimum Deposit</label>
                                <input type="number" class="form-control" value="10">
                            </div>
                            <div class="form-group">
                                <label>Maximum Deposit</label>
                                <input type="number" class="form-control" value="10000">
                            </div>
                            <div class="form-group">
                                <label>Withdrawal Processing Time (hours)</label>
                                <input type="number" class="form-control" value="24">
                            </div>
                            <div class="form-group">
                                <label>Welcome Bonus</label>
                                <input type="number" class="form-control" value="100">
                            </div>
                            <button class="btn btn-primary">Save Settings</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <script>
                function showAdminSection(section) {
                    // Hide all sections
                    document.getElementById('adminDashboard').style.display = 'none';
                    document.getElementById('adminPayments').style.display = 'none';
                    document.getElementById('adminDeposits').style.display = 'none';
                    document.getElementById('adminWithdrawals').style.display = 'none';
                    document.getElementById('adminUsers').style.display = 'none';
                    document.getElementById('adminSettings').style.display = 'none';
                    
                    // Show selected section
                    document.getElementById('admin' + section.charAt(0).toUpperCase() + section.slice(1)).style.display = 'block';
                    
                    // Update active menu item
                    document.querySelectorAll('.admin-menu a').forEach(a => a.classList.remove('active'));
                    event.target.classList.add('active');
                }
                
                function exitAdmin() {
                    if (confirm('Are you sure you want to exit admin mode?')) {
                        window.location.href = 'index.html';
                    }
                }
                
                function addPaymentMethod() {
                    const method = document.getElementById('newPaymentMethod').value;
                    const fee = document.getElementById('paymentFee').value;
                    
                    if (method) {
                        alert('Payment method "' + method + '" added with ' + fee + '% fee!');
                        document.getElementById('newPaymentMethod').value = '';
                    } else {
                        alert('Please enter a payment method name');
                    }
                }
            </script>
        </body>
        </html>
    `;
    
    // Open admin dashboard in new window
    const adminWindow = window.open('', '_blank');
    adminWindow.document.write(adminHTML);
    adminWindow.document.close();
}