// CasinoBet99 Admin JavaScript

document.addEventListener('DOMContentLoaded', function() {
    checkAdminAuth();
    loadDashboardData();
    loadUsers();
    loadDeposits();
    loadWithdrawals();
    loadSettings();
});

function checkAdminAuth() {
    if (!localStorage.getItem('adminLoggedIn')) {
        window.location.href = 'admin-login.html';
    }
}

function logout() {
    if (confirm('Logout?')) {
        localStorage.removeItem('adminLoggedIn');
        window.location.href = 'admin-login.html';
    }
}

function showAdminSection(section) {
    document.querySelectorAll('.admin-section').forEach(sec => sec.style.display = 'none');
    const targetSection = document.getElementById(section + 'Section');
    if (targetSection) targetSection.style.display = 'block';
    
    document.querySelectorAll('.admin-menu a').forEach(a => a.classList.remove('active'));
    event.target.classList.add('active');
    
    const titles = { 'dashboard': '📊 Dashboard Overview', 'users': '👥 Users Management', 'deposits': '💰 Deposit Requests', 'withdrawals': '💸 Withdrawal Requests', 'payments': '💳 Payment Settings', 'settings': '⚙️ General Settings' };
    document.querySelector('.admin-header h1').textContent = titles[section] || 'Admin Dashboard';
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 4000);
}

function loadDashboardData() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    document.getElementById('totalUsers').textContent = users.length;
    
    let totalDep = 0, totalWith = 0, pending = 0, revenue = 0;
    
    users.forEach(user => {
        const userDeposits = JSON.parse(localStorage.getItem(`deposits_${user.username}`) || '[]');
        const userWithdrawals = JSON.parse(localStorage.getItem(`withdrawals_${user.username}`) || '[]');
        
        userDeposits.forEach(dep => {
            if (dep.status === 'approved') { totalDep += dep.amount; revenue += dep.amount * 0.05; }
            else if (dep.status === 'pending') pending++;
        });
        
        userWithdrawals.forEach(withd => {
            if (withd.status === 'approved') totalWith += withd.amount;
            else if (withd.status === 'pending') pending++;
        });
    });
    
    document.getElementById('totalDepositsAdmin').textContent = '₹' + totalDep.toLocaleString('en-IN');
    document.getElementById('totalWithdrawalsAdmin').textContent = '₹' + totalWith.toLocaleString('en-IN');
    document.getElementById('pendingRequestsAdmin').textContent = pending;
    document.getElementById('totalRevenue').textContent = '₹' + revenue.toLocaleString('en-IN');
    
    loadRecentActivity();
}

function loadRecentActivity() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    let allActivities = [];
    
    users.forEach(user => {
        const userDeposits = JSON.parse(localStorage.getItem(`deposits_${user.username}`) || '[]');
        const userWithdrawals = JSON.parse(localStorage.getItem(`withdrawals_${user.username}`) || '[]');
        
        userDeposits.forEach(dep => allActivities.push({ date: dep.date, user: user.username, action: 'Deposit', amount: dep.amount, status: dep.status }));
        userWithdrawals.forEach(withd => allActivities.push({ date: withd.date, user: user.username, action: 'Withdrawal', amount: withd.amount, status: withd.status }));
    });
    
    allActivities.sort((a, b) => new Date(b.date) - new Date(a.date));
    allActivities = allActivities.slice(0, 10);
    
    const recentActivityTable = document.getElementById('recentActivity');
    if (allActivities.length === 0) {
        recentActivityTable.innerHTML = '<tr><td colspan="5" style="text-align: center;">No recent activity</td></tr>';
    } else {
        recentActivityTable.innerHTML = allActivities.map(a => `<tr><td>${a.date}</td><td>${a.user}</td><td>${a.action}</td><td>₹${a.amount.toLocaleString('en-IN')}</td><td><span class="status ${a.status}">${a.status.charAt(0).toUpperCase() + a.status.slice(1)}</span></td></tr>`).join('');
    }
}

let selectedUserForBalance = null;

function loadUsers() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const usersTable = document.getElementById('usersTable');
    
    if (users.length === 0) {
        usersTable.innerHTML = '<tr><td colspan="8" style="text-align: center;">No users registered yet</td></tr>';
    } else {
        usersTable.innerHTML = users.map((user, index) => {
            const balance = parseFloat(localStorage.getItem(`balance_${user.username}`) || '0');
            return `<tr><td>${index + 1}</td><td>${user.username}</td><td>${user.email}</td><td>${user.phone || '-'}</td><td>₹${balance.toLocaleString('en-IN')}</td><td>${user.joinedDate}</td><td><span class="status active">Active</span></td><td class="action-buttons"><button class="btn btn-primary" onclick="openBalanceModal('${user.username}')">Edit Balance</button></td></tr>`;
        }).join('');
    }
}

function openBalanceModal(username) {
    selectedUserForBalance = username;
    const balance = parseFloat(localStorage.getItem(`balance_${username}`) || '0');
    document.getElementById('modalUsername').value = username;
    document.getElementById('modalCurrentBalance').value = '₹' + balance.toLocaleString('en-IN');
    document.getElementById('modalNewBalance').value = balance;
    document.getElementById('balanceModal').classList.add('active');
}

function closeBalanceModal() {
    document.getElementById('balanceModal').classList.remove('active');
    selectedUserForBalance = null;
}

function updateUserBalance() {
    const newBalance = parseFloat(document.getElementById('modalNewBalance').value);
    if (isNaN(newBalance) || newBalance < 0) {
        showNotification('Invalid balance', 'error');
        return;
    }
    localStorage.setItem(`balance_${selectedUserForBalance}`, newBalance.toString());
    showNotification(`Balance updated for ${selectedUserForBalance}`, 'success');
    closeBalanceModal();
    loadUsers();
    loadDashboardData();
}

function loadDeposits() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    let allDeposits = [];
    
    users.forEach(user => {
        const userDeposits = JSON.parse(localStorage.getItem(`deposits_${user.username}`) || '[]');
        userDeposits.forEach(dep => allDeposits.push({ ...dep, username: user.username, email: user.email }));
    });
    
    allDeposits.sort((a, b) => new Date(b.date) - new Date(a.date));
    displayDeposits(allDeposits);
}

function displayDeposits(deposits) {
    const depositsTable = document.getElementById('depositsTable');
    if (deposits.length === 0) {
        depositsTable.innerHTML = '<tr><td colspan="8" style="text-align: center;">No deposit requests</td></tr>';
    } else {
        depositsTable.innerHTML = deposits.map(dep => `<tr><td>${dep.id}</td><td>${dep.username}<br><small>${dep.email}</small></td><td>${dep.date}</td><td>${dep.method.toUpperCase()}</td><td>₹${dep.amount.toLocaleString('en-IN')}</td><td><small>${dep.transactionId}</small></td><td><span class="status ${dep.status}">${dep.status.charAt(0).toUpperCase() + dep.status.slice(1)}</span></td><td class="action-buttons">${dep.status === 'pending' ? `<button class="btn btn-success" onclick="approveDeposit('${dep.username}', '${dep.id}')">Approve</button><button class="btn btn-danger" onclick="rejectDeposit('${dep.username}', '${dep.id}')">Reject</button>` : `<button class="btn btn-primary" onclick="viewDepositDetails('${dep.username}', '${dep.id}')">View</button>`}</td></tr>`).join('');
    }
}

function approveDeposit(username, depositId) {
    const userDeposits = JSON.parse(localStorage.getItem(`deposits_${username}`) || '[]');
    const depositIndex = userDeposits.findIndex(dep => dep.id === depositId);
    
    if (depositIndex !== -1) {
        if (!confirm(`Approve deposit of ₹${userDeposits[depositIndex].amount}?`)) return;
        
        userDeposits[depositIndex].status = 'approved';
        localStorage.setItem(`deposits_${username}`, JSON.stringify(userDeposits));
        
        const currentBalance = parseFloat(localStorage.getItem(`balance_${username}`) || '0');
        localStorage.setItem(`balance_${username}`, (currentBalance + userDeposits[depositIndex].amount).toString());
        
        showNotification('Deposit approved!', 'success');
        loadDeposits();
        loadDashboardData();
    }
}

function rejectDeposit(username, depositId) {
    const reason = prompt('Enter rejection reason:');
    if (!reason) return;
    
    const userDeposits = JSON.parse(localStorage.getItem(`deposits_${username}`) || '[]');
    const depositIndex = userDeposits.findIndex(dep => dep.id === depositId);
    
    if (depositIndex !== -1) {
        userDeposits[depositIndex].status = 'rejected';
        userDeposits[depositIndex].rejectReason = reason;
        localStorage.setItem(`deposits_${username}`, JSON.stringify(userDeposits));
        
        showNotification('Deposit rejected', 'info');
        loadDeposits();
        loadDashboardData();
    }
}

function viewDepositDetails(username, depositId) {
    const userDeposits = JSON.parse(localStorage.getItem(`deposits_${username}`) || '[]');
    const deposit = userDeposits.find(dep => dep.id === depositId);
    if (deposit) alert(`Deposit: ${deposit.id}\nUser: ${username}\nAmount: ₹${deposit.amount}\nMethod: ${deposit.method}\nStatus: ${deposit.status}`);
}

function loadWithdrawals() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    let allWithdrawals = [];
    
    users.forEach(user => {
        const userWithdrawals = JSON.parse(localStorage.getItem(`withdrawals_${user.username}`) || '[]');
        userWithdrawals.forEach(withd => allWithdrawals.push({ ...withd, username: user.username, email: user.email }));
    });
    
    allWithdrawals.sort((a, b) => new Date(b.date) - new Date(a.date));
    displayWithdrawals(allWithdrawals);
}

function displayWithdrawals(withdrawals) {
    const withdrawalsTable = document.getElementById('withdrawalsTable');
    if (withdrawals.length === 0) {
        withdrawalsTable.innerHTML = '<tr><td colspan="7" style="text-align: center;">No withdrawal requests</td></tr>';
    } else {
        withdrawalsTable.innerHTML = withdrawals.map(withd => `<tr><td>${withd.id}</td><td>${withd.username}<br><small>${withd.email}</small></td><td>${withd.date}</td><td>₹${withd.amount.toLocaleString('en-IN')}</td><td><small>${withd.bankName}<br>XXXX${withd.accountNumber.slice(-4)}</small></td><td><span class="status ${withd.status}">${withd.status.charAt(0).toUpperCase() + withd.status.slice(1)}</span></td><td class="action-buttons">${withd.status === 'pending' ? `<button class="btn btn-success" onclick="approveWithdrawal('${withd.username}', '${withd.id}')">Approve</button><button class="btn btn-danger" onclick="rejectWithdrawal('${withd.username}', '${withd.id}')">Reject</button>` : `<button class="btn btn-primary" onclick="viewWithdrawalDetails('${withd.username}', '${withd.id}')">View</button>`}</td></tr>`).join('');
    }
}

function approveWithdrawal(username, withdrawalId) {
    const userWithdrawals = JSON.parse(localStorage.getItem(`withdrawals_${username}`) || '[]');
    const withdrawalIndex = userWithdrawals.findIndex(withd => withd.id === withdrawalId);
    
    if (withdrawalIndex !== -1) {
        if (!confirm(`Approve withdrawal of ₹${userWithdrawals[withdrawalIndex].amount}?`)) return;
        
        userWithdrawals[withdrawalIndex].status = 'approved';
        localStorage.setItem(`withdrawals_${username}`, JSON.stringify(userWithdrawals));
        
        const currentBalance = parseFloat(localStorage.getItem(`balance_${username}`) || '0');
        const newBalance = Math.max(0, currentBalance - userWithdrawals[withdrawalIndex].amount);
        localStorage.setItem(`balance_${username}`, newBalance.toString());
        
        showNotification('Withdrawal approved!', 'success');
        loadWithdrawals();
        loadDashboardData();
    }
}

function rejectWithdrawal(username, withdrawalId) {
    const reason = prompt('Enter rejection reason:');
    if (!reason) return;
    
    const userWithdrawals = JSON.parse(localStorage.getItem(`withdrawals_${username}`) || '[]');
    const withdrawalIndex = userWithdrawals.findIndex(withd => withd.id === withdrawalId);
    
    if (withdrawalIndex !== -1) {
        userWithdrawals[withdrawalIndex].status = 'rejected';
        userWithdrawals[withdrawalIndex].rejectReason = reason;
        localStorage.setItem(`withdrawals_${username}`, JSON.stringify(userWithdrawals));
        
        showNotification('Withdrawal rejected', 'info');
        loadWithdrawals();
        loadDashboardData();
    }
}

function viewWithdrawalDetails(username, withdrawalId) {
    const userWithdrawals = JSON.parse(localStorage.getItem(`withdrawals_${username}`) || '[]');
    const withdrawal = userWithdrawals.find(withd => withd.id === withdrawalId);
    if (withdrawal) alert(`Withdrawal: ${withdrawal.id}\nUser: ${username}\nAmount: ₹${withdrawal.amount}\nBank: ${withdrawal.bankName}\nStatus: ${withdrawal.status}`);
}

function loadSettings() {
    const settings = JSON.parse(localStorage.getItem('adminSettings') || '{}');
    if (settings.bankAccountName) document.getElementById('bankAccountName').value = settings.bankAccountName;
    if (settings.bankAccountNumber) document.getElementById('bankAccountNumber').value = settings.bankAccountNumber;
    if (settings.bankIFSC) document.getElementById('bankIFSC').value = settings.bankIFSC;
    if (settings.bankName) document.getElementById('bankName').value = settings.bankName;
    if (settings.bankBranch) document.getElementById('bankBranch').value = settings.bankBranch;
    if (settings.upiId) document.getElementById('upiId').value = settings.upiId;
    if (settings.usdtAddress) document.getElementById('usdtAddress').value = settings.usdtAddress;
    if (settings.minDeposit) document.getElementById('minDeposit').value = settings.minDeposit;
    if (settings.maxDeposit) document.getElementById('maxDeposit').value = settings.maxDeposit;
    if (settings.minWithdrawal) document.getElementById('minWithdrawal').value = settings.minWithdrawal;
    if (settings.maxWithdrawal) document.getElementById('maxWithdrawal').value = settings.maxWithdrawal;
    if (settings.siteName) document.getElementById('siteName').value = settings.siteName;
    if (settings.contactEmail) document.getElementById('contactEmail').value = settings.contactEmail;
}

function savePaymentSettings() {
    const settings = {
        bankAccountName: document.getElementById('bankAccountName').value,
        bankAccountNumber: document.getElementById('bankAccountNumber').value,
        bankIFSC: document.getElementById('bankIFSC').value,
        bankName: document.getElementById('bankName').value,
        bankBranch: document.getElementById('bankBranch').value,
        upiId: document.getElementById('upiId').value,
        usdtAddress: document.getElementById('usdtAddress').value,
        minDeposit: document.getElementById('minDeposit').value,
        maxDeposit: document.getElementById('maxDeposit').value,
        minWithdrawal: document.getElementById('minWithdrawal').value,
        maxWithdrawal: document.getElementById('maxWithdrawal').value
    };
    localStorage.setItem('adminSettings', JSON.stringify(settings));
    showNotification('Payment settings saved!', 'success');
}

function saveGeneralSettings() {
    const settings = {
        siteName: document.getElementById('siteName').value,
        siteDescription: document.getElementById('siteDescription').value,
        contactEmail: document.getElementById('contactEmail').value,
        whatsappNumber: document.getElementById('whatsappNumber').value,
        welcomeBonus: document.getElementById('welcomeBonus').value,
        referralBonus: document.getElementById('referralBonus').value,
        dailyBonus: document.getElementById('dailyBonus').value,
        minBet: document.getElementById('minBet').value,
        maxBet: document.getElementById('maxBet').value
    };
    localStorage.setItem('adminSettings', JSON.stringify(settings));
    showNotification('General settings saved!', 'success');
}
