// CasinoBet99 Customer JavaScript

const casinoGames = [
    { id: 1, name: "Lucky 7s", category: "slots", image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=400", rating: 4.9 },
    { id: 2, name: "Fruit Frenzy", category: "slots", image: "https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=400", rating: 4.8 },
    { id: 3, name: "Diamond Rush", category: "slots", image: "https://images.unsplash.com/photo-1541278107931-e006523892df?w=400", rating: 4.7 },
    { id: 4, name: "European Roulette", category: "roulette", image: "https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=400", rating: 4.9 },
    { id: 5, name: "Blackjack Classic", category: "card", image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=400", rating: 4.9 },
    { id: 6, name: "Texas Hold'em", category: "poker", image: "https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=400", rating: 4.9 },
    { id: 7, name: "Live Roulette", category: "live", image: "https://images.unsplash.com/photo-1541278107931-e006523892df?w=400", rating: 4.9 },
    { id: 8, name: "Baccarat", category: "card", image: "https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=400", rating: 4.8 }
];

for(let i = 9; i <= 110; i++) {
    const categories = ['slots', 'table', 'card', 'roulette', 'poker', 'live'];
    const category = categories[i % categories.length];
    casinoGames.push({
        id: i,
        name: `Game ${i}`,
        category: category,
        image: `https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=400`,
        rating: (4 + Math.random()).toFixed(1)
    });
}

let currentUser = null;
let userBalance = 0;
let deposits = [];
let withdrawals = [];
let selectedDepositMethod = null;

document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    loadGames();
    loadUserData();
});

function checkAuth() {
    const user = localStorage.getItem('currentUser');
    if (!user) {
        window.location.href = 'customer-login.html';
    } else {
        currentUser = JSON.parse(user);
        loadUserProfile();
    }
}

function loadUserProfile() {
    document.getElementById('profileUsername').value = currentUser.username || '';
    document.getElementById('profileEmail').value = currentUser.email || '';
    document.getElementById('profilePhone').value = currentUser.phone || '';
    document.getElementById('profileJoined').value = currentUser.joinedDate || '';
}

function loadUserData() {
    const savedBalance = localStorage.getItem(`balance_${currentUser.username}`);
    const savedDeposits = localStorage.getItem(`deposits_${currentUser.username}`);
    const savedWithdrawals = localStorage.getItem(`withdrawals_${currentUser.username}`);
    
    if (savedBalance) userBalance = parseFloat(savedBalance);
    if (savedDeposits) deposits = JSON.parse(savedDeposits);
    if (savedWithdrawals) withdrawals = JSON.parse(savedWithdrawals);
    
    updateBalanceDisplay();
    updateTransactionTables();
}

function updateBalanceDisplay() {
    const balanceElements = document.querySelectorAll('#userBalance, #walletBalance');
    balanceElements.forEach(el => el.textContent = '₹' + userBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 }));
    
    let totalDep = 0, totalWith = 0, pending = 0;
    deposits.forEach(dep => { if (dep.status === 'approved') totalDep += dep.amount; });
    withdrawals.forEach(withd => { if (withd.status === 'approved') totalWith += withd.amount; if (withd.status === 'pending') pending++; });
    
    document.getElementById('totalDeposits').textContent = '₹' + totalDep.toLocaleString('en-IN');
    document.getElementById('totalWithdrawals').textContent = '₹' + totalWith.toLocaleString('en-IN');
    document.getElementById('pendingRequests').textContent = pending;
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 4000);
}

function showPage(pageName) {
    document.querySelectorAll('.page').forEach(page => page.style.display = 'none');
    const targetPage = document.getElementById(pageName + 'Page');
    if (targetPage) targetPage.style.display = 'block';
}

function loadGames() {
    const popularGamesContainer = document.getElementById('popularGames');
    popularGamesContainer.innerHTML = casinoGames.slice(0, 8).map(game => createGameCard(game)).join('');
    
    const allGamesContainer = document.getElementById('allGames');
    allGamesContainer.innerHTML = casinoGames.map(game => createGameCard(game)).join('');
}

function createGameCard(game) {
    return `<div class="game-card" onclick="playGame(${game.id})">
        <img src="${game.image}" alt="${game.name}">
        <div class="game-info"><h3>${game.name}</h3><p>★ ${game.rating}</p></div>
    </div>`;
}

function filterGames(category) {
    document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    let filteredGames = category === 'all' ? casinoGames : casinoGames.filter(game => game.category === category);
    document.getElementById('allGames').innerHTML = filteredGames.map(game => createGameCard(game)).join('');
}

function playGame(gameId) {
    const game = casinoGames.find(g => g.id === gameId);
    if (!game) return;
    
    const betAmount = 10;
    if (betAmount > userBalance) {
        showNotification('Insufficient balance! Please deposit funds.', 'error');
        return;
    }
    
    userBalance -= betAmount;
    updateBalanceDisplay();
    localStorage.setItem(`balance_${currentUser.username}`, userBalance.toString());
    
    const win = Math.random() > 0.5;
    const multiplier = [1, 2, 5, 10][Math.floor(Math.random() * 4)];
    
    setTimeout(() => {
        if (win) {
            const winnings = betAmount * multiplier;
            userBalance += winnings;
            updateBalanceDisplay();
            localStorage.setItem(`balance_${currentUser.username}`, userBalance.toString());
            showNotification(`🎉 You won ₹${winnings} in ${game.name}!`, 'success');
        } else {
            showNotification(`Better luck next time!`, 'error');
        }
    }, 1000);
}

function showDepositModal() {
    document.getElementById('depositModal').classList.add('active');
}

function closeDepositModal() {
    document.getElementById('depositModal').classList.remove('active');
    selectedDepositMethod = null;
    document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
    document.querySelectorAll('[id$="Details"]').forEach(el => el.style.display = 'none');
}

function selectDepositMethod(element, method) {
    document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    selectedDepositMethod = method;
    document.querySelectorAll('[id$="Details"]').forEach(el => el.style.display = 'none');
    document.getElementById(method + 'Details').style.display = 'block';
}

function submitDeposit() {
    const amount = parseFloat(document.getElementById('depositAmount').value);
    
    if (!selectedDepositMethod) {
        showNotification('Please select a payment method', 'error');
        return;
    }
    
    if (amount < 100) {
        showNotification('Minimum deposit is ₹100', 'error');
        return;
    }
    
    let transactionId = '';
    switch(selectedDepositMethod) {
        case 'bank': transactionId = document.getElementById('depositTransactionId').value; break;
        case 'upi': transactionId = document.getElementById('upiTransactionId').value; break;
        case 'usdt': transactionId = document.getElementById('usdtTransactionId').value; break;
        case 'qr': transactionId = document.getElementById('qrTransactionId').value; break;
    }
    
    if (!transactionId) {
        showNotification('Please enter transaction ID', 'error');
        return;
    }
    
    const deposit = {
        id: 'DEP' + Date.now(),
        date: new Date().toLocaleString(),
        method: selectedDepositMethod,
        amount: amount,
        transactionId: transactionId,
        status: 'pending',
        userId: currentUser.username
    };
    
    deposits.unshift(deposit);
    localStorage.setItem(`deposits_${currentUser.username}`, JSON.stringify(deposits));
    updateTransactionTables();
    closeDepositModal();
    showNotification('Deposit request submitted! Admin will approve within 24 hours.', 'success');
}

function showWithdrawModal() {
    document.getElementById('withdrawModal').classList.add('active');
}

function closeWithdrawModal() {
    document.getElementById('withdrawModal').classList.remove('active');
}

function submitWithdraw() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    const accountName = document.getElementById('withdrawAccountName').value;
    const accountNumber = document.getElementById('withdrawAccountNumber').value;
    const ifsc = document.getElementById('withdrawIFSC').value;
    const bankName = document.getElementById('withdrawBankName').value;
    const branch = document.getElementById('withdrawBranch').value;
    
    if (amount < 100) {
        showNotification('Minimum withdrawal is ₹100', 'error');
        return;
    }
    
    if (amount > userBalance) {
        showNotification('Insufficient balance!', 'error');
        return;
    }
    
    if (!accountName || !accountNumber || !ifsc || !bankName || !branch) {
        showNotification('Please fill all bank details', 'error');
        return;
    }
    
    const withdrawal = {
        id: 'WTH' + Date.now(),
        date: new Date().toLocaleString(),
        amount: amount,
        accountName: accountName,
        accountNumber: accountNumber,
        ifsc: ifsc,
        bankName: bankName,
        branch: branch,
        status: 'pending',
        userId: currentUser.username
    };
    
    withdrawals.unshift(withdrawal);
    localStorage.setItem(`withdrawals_${currentUser.username}`, JSON.stringify(withdrawals));
    updateTransactionTables();
    closeWithdrawModal();
    showNotification('Withdrawal request submitted! Admin will process within 24-48 hours.', 'success');
}

function updateTransactionTables() {
    const depositsTable = document.getElementById('depositsTable');
    if (deposits.length === 0) {
        depositsTable.innerHTML = '<tr><td colspan="5" style="text-align: center;">No deposits yet</td></tr>';
    } else {
        depositsTable.innerHTML = deposits.map(dep => `
            <tr>
                <td>${dep.date}</td>
                <td>${dep.method.toUpperCase()}</td>
                <td>₹${dep.amount.toLocaleString('en-IN')}</td>
                <td>${dep.id}</td>
                <td><span class="status ${dep.status}">${dep.status.charAt(0).toUpperCase() + dep.status.slice(1)}</span></td>
            </tr>
        `).join('');
    }
    
    const withdrawalsTable = document.getElementById('withdrawalsTable');
    if (withdrawals.length === 0) {
        withdrawalsTable.innerHTML = '<tr><td colspan="5" style="text-align: center;">No withdrawals yet</td></tr>';
    } else {
        withdrawalsTable.innerHTML = withdrawals.map(withd => `
            <tr>
                <td>${withd.date}</td>
                <td>${withd.bankName} - ${withd.accountNumber.slice(-4)}</td>
                <td>₹${withd.amount.toLocaleString('en-IN')}</td>
                <td>${withd.id}</td>
                <td><span class="status ${withd.status}">${withd.status.charAt(0).toUpperCase() + withd.status.slice(1)}</span></td>
            </tr>
        `).join('');
    }
}

function showWalletTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.getElementById(tabName + 'Tab').classList.add('active');
    event.target.classList.add('active');
}

function updateProfile() {
    currentUser.username = document.getElementById('profileUsername').value;
    currentUser.email = document.getElementById('profileEmail').value;
    currentUser.phone = document.getElementById('profilePhone').value;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    showNotification('Profile updated successfully!', 'success');
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'customer-login.html';
    }
}
